package exercicio03;

import java.util.Scanner;

import filasSequenciais.FilaSequencialInt;

public class Exercicio__03 {

	public static void main(String[] args) {
		FilaSequencialInt fila = new FilaSequencialInt();
		fila.init();
		Scanner teclado = new Scanner(System.in);
		int rm;
		int i = 0;
		int aux;

		do {
			System.out.print("Informe o " + (i + 1) + "� RM ou -1 para finalizar. ");
			rm = teclado.nextInt();
			fila.enqueue(rm);
			aux = i;
			i++;
		} while (rm != -1 && i<fila.N);
		i=0;
		
		do {				
			System.out.println((i + 1) + "� aluno a ser atendido: " + fila.dequeue());
			i++;
		} while (i<aux);

			

		teclado.close();
	}

}
