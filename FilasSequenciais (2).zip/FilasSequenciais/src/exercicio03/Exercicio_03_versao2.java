package exercicio03;

import java.util.Scanner;

import filasSequenciais.FilaSequencialInt;

public class Exercicio_03_versao2 {

	public static void main(String[] args) {
		FilaSequencialInt fila = new FilaSequencialInt();
		fila.init();
		Scanner teclado = new Scanner(System.in);
		int rm, i;

		for (i = 0; i < fila.N; i++) {
			System.out.print("Informe o " + (i + 1) + "� RM: ");
			rm = teclado.nextInt();
			fila.enqueue(rm);
			teclado.close();
		}

		for (i = 0; i < fila.N; i++) {
			System.out.println((i + 1) + "� aluno a ser atendido: " + fila.dequeue());
		}
	}

}
