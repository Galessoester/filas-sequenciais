package exercicio04;

import java.util.Scanner;
import filasSequenciais.FilaSequencialInt;

public class Exercicio_04_versao2 {

	public static void main(String[] args) {
		FilaSequencialInt fila = new FilaSequencialInt();
		fila.init();
		Scanner teclado = new Scanner(System.in);
		int opcao, valor, i = 0;

		do {
			String frase = "Escolha uma op��o\n1.Identificar Processo\n2.Processar PID\n3.Encerrar programa.";
			System.out.println(frase);
			opcao = teclado.nextInt();

			if (opcao == 1) {
				System.out.print("PID: ");
				valor = teclado.nextInt();
				fila.enqueue(valor);
			}
			if (opcao == 2) {
				valor = fila.dequeue();
				System.out.println("processo " +valor +" est� sendo executado");
				System.out.println("O processo foi conclu�do? (Digite 1 para SIM e 2 para N�O)");
				opcao = teclado.nextInt();
				if (opcao == 1) {
					System.out.println("Processo finalizado.");
				} else {
					fila.enqueue(valor);
				}
			}
			System.out.println("");
		} while (opcao !=3 && fila.isEmpty());

		teclado.close();

	}

}
