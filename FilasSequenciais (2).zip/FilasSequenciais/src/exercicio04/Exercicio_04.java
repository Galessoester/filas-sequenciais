package exercicio04;

import java.util.Scanner;
import filasSequenciais.FilaSequencialInt;

public class Exercicio_04 {

	public static void main(String[] args) {
		FilaSequencialInt fila = new FilaSequencialInt();
		fila.init();
		Scanner teclado = new Scanner(System.in);
		int opcao, pid, i = 0;

		do {
			String frase = "Escolha uma op��o\n1.Inserir identifica��o\n2.Processar pides\n3.Encerrar programa.";
			System.out.println(frase);
			opcao = teclado.nextInt();

			if (opcao == 1) {
				System.out.print("Informe o n�mero de identifica��o: ");
				pid = teclado.nextInt();
				fila.enqueue(pid);

			}
			if (opcao == 2) {
				pid = fila.dequeue();
				System.out.println(pid);
				System.out.println("O processo foi conclu�do? (Digite 1 para SIM e 2 para N�O)");
				opcao = teclado.nextInt();
				if (opcao == 1) {
					System.out.println("Processo finalizado.");
				} else {
					fila.enqueue(pid);
				}

			}
			if (opcao == 3) {
				if (!fila.isEmpty()) {
					System.out.println("Ainda tem processos na fila. Deseja encerrar mesmo assim?");
					System.out.println("(1-SIM / 2-N�O)");
					opcao = teclado.nextInt();
					if (opcao == 1) {
						System.out.println("Encerrando...");
						break;
					}
				} else {
					System.out.println("Encerrando...");
					break;
				}
			}
			System.out.println("");
		} while (i < fila.N);

		teclado.close();

	}

}
