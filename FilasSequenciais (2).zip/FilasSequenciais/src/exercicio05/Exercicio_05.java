package exercicio05;

import java.util.Scanner;
import filasSequenciais.FilaSequencialString;

public class Exercicio_05 {

	public static void main(String[] args) {
		FilaSequencialString fila = new FilaSequencialString();
		fila.init();
		Scanner teclado = new Scanner(System.in);
		int opcao, i = 0;
		String paciente;

		do {
			String frase = "Escolha uma op��o\n1.Cadastrar paciente\n2.Chamar para atendimento\n3.Encerrar programa.";
			System.out.println(frase);
			opcao = teclado.nextInt();

			if (opcao == 1) {
				System.out.print("Informe o nome do paciente: ");
				paciente = teclado.next();
				fila.enqueue(paciente);
			}

			if (opcao == 2) {
				paciente = fila.dequeue();
				System.out.println("Pr�ximo a ser atendido: " + paciente);
			}
			System.out.println("");
		} while (opcao != 3 && i < fila.N);

		teclado.close();

	}

}
